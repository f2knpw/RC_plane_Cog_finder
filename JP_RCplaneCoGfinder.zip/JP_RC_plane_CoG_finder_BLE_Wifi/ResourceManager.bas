﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=7.3
@EndOfDesignText@
'Code module
'Subs in this code module will be accessible from all modules.
Sub Process_Globals
	Dim ApplicationResources As Resources
End Sub

'	'	returns the application string resource identified by TagValue
'	if no string resource is found then the DefaultValue is returned
Sub GetApplicationString(TagValue As String, DefaultValue As String) As String
	Dim ResourceId As Int
	ResourceId=ApplicationResources.GetIdentifier(TagValue, "string", ApplicationResources.PackageName)
	If ResourceId=0 Then
		Return DefaultValue
	Else
		Return ApplicationResources.GetString(ResourceId)
	End If
End Sub

'	returns the application string array resource identified by TagValue
'	if no string array resource is found then DefaultValues is returned
Sub GetApplicationStringArray(TagValue As String, DefaultValues() As String) As String()
	Dim ResourceId As Int
	ResourceId=ApplicationResources.GetIdentifier(TagValue, "array", ApplicationResources.PackageName)
	If ResourceId=0 Then
		Return DefaultValues
	Else
		Return ApplicationResources.GetStringArray(ResourceId)
	End If
End Sub

'	localize all Views in Activity1
'	if a View has no Tag value, or a Tag value exists but no string or string array resource is found for the Tag value then the View's Text property or properties will be unchanged
Sub LocalizeActivity(Activity1 As Activity)
	For Each View1 As View In Activity1.GetAllViewsRecursive
		LocalizeView(View1)
	Next
End Sub

'	localize all Views in Panel1
'	if a View has no Tag value, or a Tag value exists but no string or string array resource is found for the Tag value then the View's Text property or properties will be unchanged
Sub LocalizePanel(Panel1 As Panel)
	For Each View1 As View In Panel1.GetAllViewsRecursive
		LocalizeView(View1)
	Next
End Sub

'	localize a View
'	if the View has no Tag value, or a Tag value exists but no string or string array resource is found for the Tag value then the View's Text property or properties will be unchanged
Sub LocalizeView(View1 As View)
	If View1.Tag<>Null And View1.Tag Is String Then
		Dim TagValue As String=View1.Tag
		If TagValue<>"" Then
			'	the View's Tag property has been set
			'	check if we have a string resource for the TagValue
			Dim ResourceId As Int=ApplicationResources.GetIdentifier(TagValue, "string", ApplicationResources.PackageName)
			'	a ResourceId value of 0 indicates that no string resource exists for the TagValue
			If ResourceId<>0 Then
				'	a string resource found for the TagValue
				'	check to see if the View is a View with a single Text property and set it's Text property
				Dim ResourceString As String=ApplicationResources.GetString(ResourceId)
				If View1 Is Button Then
					Dim Button1 As Button=View1
					Button1.Text=ResourceString
				Else If View1 Is CheckBox Then
					Dim CheckBox1 As CheckBox=View1
					CheckBox1.Text=ResourceString
				Else If View1 Is Label Then
					Dim Label1 As Label=View1
					Label1.Text=ResourceString
				Else If View1 Is RadioButton Then
					Dim RadioButton1 As RadioButton=View1
					RadioButton1.Text=ResourceString
				Else
					'	we have a TagValue and a string resource but have not yet implemented localization of this type of View
					'	we need to add another Else If condition to localize this type of View
					Log("LocalizeView: View with Tag value of "&TagValue&" is of a type not yet implemented")
					'	if necessary we could also log the type of the View to enable us to trace where the View has been created
				End If
			Else
				'	no string resource found for the TagValue
				'	check if we have a string array resource for the TagValue
				ResourceId=ApplicationResources.GetIdentifier(TagValue, "array", ApplicationResources.PackageName)
				If ResourceId<>0 Then
					'	a string array resource found for the TagValue
					'	check to see if the View is a View with multiple text properties and set it's text properties
					Dim ResourceStrings() As String=ApplicationResources.GetStringArray(ResourceId)
					If View1 Is Spinner Then
						Dim Spinner1 As Spinner=View1
						Spinner1.AddAll(ResourceStrings)
					Else If View1 Is ToggleButton Then
						Dim ToggleButton1 As ToggleButton=View1
						ToggleButton1.TextOff=ResourceStrings(0)
						ToggleButton1.TextOn=ResourceStrings(1)
					Else
						'	we have a TagValue and a string array resource but have not yet implemented localization of this type of View
						'	we need to add another Else If condition to localize this type of View
						Log("LocalizeView: View with Tag value of "&TagValue&" is of a type not yet implemented")
						'	if necessary we could also log the type of the View to enable us to trace where the View has been created
					End If
				Else
					'	no string or string array resource found for the TagValue
					'	check if we have a drawable resource for the TagValue
					ResourceId=ApplicationResources.GetIdentifier(TagValue, "drawable", ApplicationResources.PackageName)
					If ResourceId<>0 Then
						'	is the View an ImageView?
						If View1 Is ImageView Then
							Dim BitmapDrawable1 As BitmapDrawable=ApplicationResources.GetDrawable(ResourceId)
							Dim ImageView1 As ImageView=View1
							ImageView1.Bitmap=BitmapDrawable1.Bitmap
						End If
						'	we have a TagValue and a drawable resource but the View is not an ImageView
						
					Else
						'	no string, string array or drawable resource found for the TagValue
						'	this could be an error in our localization - we've failed to create a resource or set an incorrect Tag value
						'	or were still localizing and this View has not yet been localized
						'	log a message to enable us to check further
						Log("LocalizeView: the View has a Tag value set '"&TagValue&"' but no localized resource was found")
						'	log the View and set it's background color to red - this should help us identify the View
						'	once localization is complete we'll want to comment out or remove these next two lines
						'Log(View1)
						View1.Color=Colors.Red
					End If
				End If
			End If
		End If
	End If
End Sub
