﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=Service
Version=7.8
@EndOfDesignText@
#Region  Service Attributes 
	#StartAtBoot: False
	#ExcludeFromLibrary: True
#End Region

Sub Process_Globals
	Public manager As BleManager2
	Public currentStateText As String = "UNKNOWN"
	Public serviceId, charId As String
	Private connected As Boolean
	Public rp As RuntimePermissions
	Dim firstRead As Boolean = False
	Dim JsonString As String = ""

	
	
	Public shared As String
	
	Dim TimeoutTimer As Timer
	
	'keyvalue store
	Public kvs As KeyValueStore
	

	
	'FileProvder
	'Public Provider As FileProvider

End Sub

Sub Service_Create
	'BLE
	manager.Initialize("manager")
	serviceId = "4fafc201-1fb5-459e-8fcc-c5c9c3319160" 'ESP32 EDA Monitor
	charId = "beb5483e-36e1-4688-b7f5-ea07361b26bb"
	TimeoutTimer.Initialize("TimeoutTimer", 10000)


	'keyvalue store
	kvs.Initialize(File.DirInternal, "datastore2")

End Sub



Sub Service_Destroy
	TimeoutTimer.Enabled = False
End Sub

Sub Manager_StateChanged (State As Int)
	Select State
		Case manager.STATE_POWERED_OFF
			currentStateText = "POWERED OFF"
		Case manager.STATE_POWERED_ON
			currentStateText = "POWERED ON"
		Case manager.STATE_UNSUPPORTED
			currentStateText = "UNSUPPORTED"
	End Select
	'CallSub(Main, "BleStateChanged")
	StartScan
End Sub

Public Sub StartScan
	If rp.Check(rp.PERMISSION_ACCESS_FINE_LOCATION) And manager.State = manager.STATE_POWERED_ON Then
		Log("scanning")
		'manager.Scan2(Array (serviceId), False)
		manager.Scan(Null)
	Else
		Log("No permission or not powered on")
		'CallSub(Main, "GetPermission")
	End If
End Sub


Sub Manager_DeviceFound (Name As String, DeviceId As String, AdvertisingData As Map, RSSI As Double)
	Log($"Device found: ${Name}"$)
	'manager.Connect2(Id, False)
	
	Log($"****************
	Name: ${Name}
	DeviceId: ${DeviceId}"$)

	If (Name = "JP CoGfinder") Then
		manager.StopScan
		Log($"Connecting to: ${DeviceId}"$)
		Try
			manager.Connect(DeviceId)
			TimeoutTimer.Enabled = True
		Catch
			Log(LastException)
			StartScan
		End Try
	End If
End Sub


Sub manager_Connected (Services As List)
	connected = True
	Main.BLEconnected = True
	Log(serviceId)
	firstRead = True
	manager.ReadData(serviceId)
	TimeoutTimer.Enabled = False
End Sub

Sub TimeoutTimer_Tick
	TimeoutTimer.Enabled = False
	manager.Disconnect
	ToastMessageShow("can't connect. Please relaunch bluetooth", True)
	StartScan
End Sub

Sub Manager_Disconnected
	connected = False
	Main.BLEconnected = False
	If Main.isactive Then
	
		Log("disconnected, rescan")
		manager.Scan(Null)
	Else
		Log( "JP CoGfinder --> bye !")
		'ToastMessageShow("Variometer : starter destroyed --> bye !", True)
		Sleep(1000)
		ExitApplication
	End If
End Sub


Sub Manager_DataAvailable (sid As String, Characteristics As Map)
	If firstRead Then
		firstRead = False
		manager.SetNotify(serviceId, charId, True)
		Return
	End If

	Dim b() As Byte =  Characteristics.Get(charId)
	Dim s As String = ""
	For i = 0 To b.length-1
		s = s &  Chr(b(i))
	Next
	JsonString = JsonString & s
	If JsonString.EndsWith("}") Then	'Json message is finished
		'Log ("BLE data : " & JsonString)
	
		Try
			Dim parser As JSONParser
			parser.Initialize(JsonString)
			Dim root As Map = parser.NextObject
	Main.length = root.Get("L")
				Main.L1 = root.Get("L1")
				Main.L2 = root.Get("L2")
				Main.frontScale = root.Get("F")
				Main.backScale = root.Get("B")
				
				Main.CoG = root.Get("C")
				Main.targetCoG = root.Get("TC")
			JsonString = ""
			If (Main.isactive) Then CallSub(Main, "DrawLine")
		Catch
			Log(LastException)
			JsonString = ""
		End Try
	End If
	
	
End Sub

Private Sub SendMsg(msg As String)
	Dim b() As Byte = msg.GetBytes("UTF8") 'convert to bytes
	Try
		manager.WriteData(serviceId, charId, b)
	Catch
		Log(LastException)
	End Try
End Sub

Public Sub SendMessage(msg() As Byte)
	If Not(connected) Then Return
	manager.WriteData(serviceId, charId, msg)
End Sub


'Return true to allow the OS default exceptions handler to handle the uncaught exception.
Sub Application_Error (Error As Exception, StackTrace As String) As Boolean
	Return True
End Sub

